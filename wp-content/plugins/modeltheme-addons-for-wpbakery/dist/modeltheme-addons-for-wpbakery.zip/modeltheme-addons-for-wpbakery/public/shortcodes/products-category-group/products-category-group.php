<?php
if ( ! defined( 'ABSPATH' ) ) {
  die( '-1' );
}

function modeltheme_addons_for_wpbakery_collectors_group($params, $content) {
  extract( shortcode_atts( 
    array(
      'image_shape'               => '',
      'list_image'                => '',
      'collectors_groups'       => '',
      'member_name'               => '',
      'member_position'           => '',
      'member_description'        => '',
      'title_color'               => '',
      'position_color'            => '',
      'description_color'         => '',
      'description_size'          => '',
      'quote_testimonial'         => '',
      'quote_color'               => '',
      'quote_size'                => '',
      'quote_image'               => '',
      // carousel
      'delay'                 => '',
      'items_desktop'         => '4',
      'items_tablet'          => '',
      'items_mobile'          => '',
      'pagination'            => '',
      'navigation'            => 'true',
      'autoplay'              => '',
      'space_items'           => '',
      'touch_move'            => '',
      'effect'                => '',
      'grab_cursor'           => '',
      'infinite_loop'         => 'true',
      'centered_slides'      => '',
      'carousel'              => '',
      'columns'               => '',
      'layout'                => 'carousel',
      'category'                => '',
      'transition'        =>'true',



    ), $params ) );
    
    $title_color_style = '';
    if ($title_color) {
      $title_color_style = 'color:'.$title_color.';';
    }
    $position_color_style = '';
    if ($position_color) {
      $position_color_style = 'color:'.$position_color.';';
    }
    $description_color_style = '';
    if ($description_color) {
      $description_color_style = 'color:'.$description_color.';';
    }
   
    wp_enqueue_style( 'collectors-group-css', plugins_url( '../../css/collectors-group.css' , __FILE__ ));
    $collectors_groups = vc_param_group_parse_atts($params['collectors_groups']);

    $id = 'mt-addons-carousel-'.uniqid();
    $carousel_item_class = $columns;
    $carousel_holder_class = '';
    $swiper_wrapped_start = '';
    $swiper_wrapped_end = '';
    $swiper_container_start = '';
    $swiper_container_end = '';
    $html_post_swiper_wrapper = '';

    if ($layout == "carousel" or $layout == ""){
      $carousel_holder_class = 'mt-addons-swipper swiper';
      $carousel_item_class = 'swiper-slide';

      $swiper_wrapped_start = '<div class="swiper-wrapper">';
      $swiper_wrapped_end = '</div>';

      if ($transition == "true") {
        $swiper_container_start = '<div class="mt-addons-swiper-container">';
        $swiper_container_end = '</div>';
      }

      if ($navigation == "true") {
        // next/prev
        $html_post_swiper_wrapper .= '<i class="far fa-arrow-left swiper-button-prev"></i><i class="far fa-arrow-right swiper-button-next"></i>';
      }
      if ($pagination == "true") {
        // next/prev
        $html_post_swiper_wrapper .= '<div class="swiper-pagination"></div>';
      }

      // SWIPER SLIDER
      wp_enqueue_style( 'swiper-bundle', plugins_url( '../../css/plugins/swiperjs/swiper-bundle.min.css' , __FILE__ ));
      wp_enqueue_script( 'swipper-bundle', plugins_url( '../../js/plugins/swiperjs/swiper-bundle.min.js' , __FILE__));
      wp_enqueue_script( 'swipper', plugins_url( '../../js/swiper.js' , __FILE__));
    }
 
    ob_start(); ?>
    <?php //swiper container start ?>
    <?php echo wp_kses_post($swiper_container_start); ?>
      <div id="<?php echo esc_attr($id); ?>" 
        <?php modeltheme_addons_swiper_attributes($id, $autoplay, $delay, $items_desktop, $navigation, $pagination, $items_mobile, $items_tablet, $space_items, $touch_move, $effect, $grab_cursor, $infinite_loop, $centered_slides); ?>
        class="mt-addons-collectors-carusel <?php echo esc_attr($carousel_holder_class); ?>">
          <?php //swiper wrapped start ?>
          <?php echo wp_kses_post($swiper_wrapped_start); ?>

            <?php if ($collectors_groups) { ?>
              <?php foreach ($collectors_groups as $collector) {
                if (!array_key_exists('category', $collector)) {
                  $category = 'Uncategorized';
                }else{
                  $category = $collector['category'];
                }
                $cat   = get_term_by('slug', $category, 'product_cat');
                if($cat) {
                $cat_link  = get_term_link( $category, 'product_cat' );
                $cat_img_id = get_term_meta( $cat->term_id, 'thumbnail_id', true );  
                $category_src = wp_get_attachment_image_src( $cat_img_id, 'enefti_post_widget_pic70x70' );
                $args_prods = array(
                    'posts_per_page'   => 4,
                    'order'            => 'ASC',
                    'post_type'        => 'product',
                    'tax_query' => array(
                      array(
                          'taxonomy' => 'product_cat',
                          'field' => 'slug',
                          'terms' => $category
                      )),
                    'post_status'      => 'publish' 
                ); 
                $prods = get_posts($args_prods); ?>

                <div class="<?php echo esc_attr($carousel_item_class); ?>">
                  <div class="mt-addons-images-wrapper">
                    <?php foreach ($prods as $prod) {
                      $thumbnail_src = wp_get_attachment_image_src( get_post_thumbnail_id( $prod->ID ), 'enefti_collections149x100' );
                      if ($thumbnail_src) {
                          $post_img = '<img class="portfolio_post_image" src="'. esc_url($thumbnail_src[0]) . '" alt="'.$prod->post_title.'" />';
                      }else{
                          $post_img = '<img class="portfolio_post_image" src="http://via.placeholder.com/144x100" alt="'.$prod->post_title.'" />';
                      } ?>        
                      <a class="modeltheme_media_image" title="<?php echo esc_attr($prod->post_title);?>" href="<?php echo esc_url(get_permalink($prod->ID));?>"><?php echo $post_img; ?></a>
                    <?php } ?>
                  </div>
                  <div class="mt-addons-collector-wrapper">
                    <?php if($category_src) { ?>
                      <img class="cat-image" alt="cat-image" src="<?php echo $category_src[0];?>">
                    <?php } else { ?>
                      <img class="cat-image" alt="cat-image" src="http://via.placeholder.com/70x70">
                    <?php } ?>
                  </div>
                  <div class="mt-addons-info-wrapper">
                    <a class="#categoryid_<?php echo esc_attr($cat->term_id);?>" href="<?php echo esc_url($cat_link);?>"><span class="mt-addons-title"><? echo esc_attr($cat->name);?></span></a>
                    <span class="mt-addons-subtitle"><strong><?php echo esc_attr($cat->count);?> items</strong></span><br>
                  </div> 
                </div>
              <?php } ?>
              <?php } ?>
            <?php } ?>
          <?php //swiper wrapped end ?>
          <?php echo wp_kses_post($swiper_wrapped_end); ?>
      </div>
      <?php //pagination/navigation ?>
      <?php echo wp_kses_post($html_post_swiper_wrapper); ?>
      <?php //swiper container end ?>
      <?php echo wp_kses_post($swiper_container_end); ?>

    <?php
    return ob_get_clean();
}
add_shortcode('mt-addons-collectors-group', 'modeltheme_addons_for_wpbakery_collectors_group');

add_action('init','mt_addons_collector_group');
function mt_addons_collector_group(){

  if (function_exists('vc_map')) {
    $product_category = array();
    if ( class_exists( 'WooCommerce' ) ) {
      $product_category_tax = get_terms( 'product_cat', array(
        'parent'      => '0'
      ));
      if ($product_category_tax) {
        foreach ( $product_category_tax as $term ) {
          if ($term) {
             $product_category[$term->name] = $term->slug;
          }
        }
      }
    }
  
  $params = array(
    array(
      'type' => 'param_group',
      'value' => '',
      'param_name' => 'collectors_groups',
      // Note params is mapped inside param-group:
      'params' => array(
        array(
            "type" => "dropdown",
            "holder" => "div",
            "class" => "",
            "heading" => esc_attr__("Category", 'modeltheme-addons-for-wpbakery'),
            "param_name" => "category",
            "description" => esc_attr__("Select Category", 'modeltheme-addons-for-wpbakery'),
            "std" => 'Select',
            "value" => $product_category
          )
      ),
    ),
  );

  $swiper_fields_array = modeltheme_addons_swiper_vc_fields();
  if ($swiper_fields_array) {
    foreach ($swiper_fields_array as $swiper_fields) {
      $params[] = $swiper_fields;
    }
  }
  vc_map(
    array(
      "name" => esc_attr__("MT: Product Category Group", 'modeltheme-addons-for-wpbakery'),
      "base" => "mt-addons-collectors-group",
      "category" => esc_attr__('MT Addons', 'modeltheme-addons-for-wpbakery'),
      "icon" => plugins_url( 'images/product-grid.svg', __FILE__ ),
      "params" => $params,
  ));
}}