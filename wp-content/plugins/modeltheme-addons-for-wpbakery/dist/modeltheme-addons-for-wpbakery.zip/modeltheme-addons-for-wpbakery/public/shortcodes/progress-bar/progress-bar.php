<?php
if ( ! defined( 'ABSPATH' ) ) {
  die( '-1' );
}

function modeltheme_addons_for_wpbakery_progress_bar($params, $content) {
  extract( shortcode_atts( 
    array(
      'width_progress'  => '', 
      'bar_label'  => '', 
      'bar_value'  => '',
      'color'      => '',
      'background_progress'      => ''


    ), $params ) );
   
    wp_enqueue_style( 'mt-progress-bar', plugins_url( '../../css/progress-bar.css' , __FILE__ ));
    wp_enqueue_script( 'progress-bar', plugins_url( '../../js/progress-bar.js' , __FILE__));

    $overlay_bg_style = '';
    if ($background_progress) {
      $overlay_bg_style = 'background:'.$background_progress.';';
    }

    ob_start(); ?>
    <div class="mt-addons-progress-bar" style="width:<?php echo esc_attr($width_progress.'%');?>;">
          <span class="mt-addons-progress-bar-title"><?php echo esc_html__($bar_label); ?></span>
      <div class="mt-addons-progress-bar-done" style="<?php echo $overlay_bg_style; ?>;color:<?php echo esc_attr($color); ?>;" data-progress="<?php echo esc_attr($bar_value); ?>"><?php echo esc_attr($bar_value.'%'); ?>
      </div>
    </div>
    <?php 
    return ob_get_clean();
}
add_shortcode('mt-addons-progress-bar', 'modeltheme_addons_for_wpbakery_progress_bar');

//VC Map
if (function_exists('vc_map')) {
  vc_map(
    array(
      "name" => esc_attr__("MT: Progress Bar", 'modeltheme-addons-for-wpbakery'),
      "base" => "mt-addons-progress-bar",
      "category" => esc_attr__('MT Addons', 'modeltheme-addons-for-wpbakery'),
      "icon" => plugins_url( 'images/progress-bar.svg', __FILE__ ),
      "params" => array(
        array(
          "type" => "dropdown",
          "holder" => "div",
          "class" => "",
          "heading" => esc_attr__("Alert style", 'modeltheme-addons-for-wpbakery'),
          "param_name" => "bar_scope",
          "value" => array(
            'Select Option'     => '',
            esc_attr__('Success', 'modeltheme-addons-for-wpbakery')    => 'success',
            esc_attr__('Info', 'modeltheme-addons-for-wpbakery')    => 'info',
            esc_attr__('Warning', 'modeltheme-addons-for-wpbakery')    => 'warning',
            esc_attr__('Danger', 'modeltheme-addons-for-wpbakery')    => 'danger'
          )
        ),
        array(
          "type" => "dropdown",
          "holder" => "div",
          "class" => "",
          "heading" => esc_attr__("Progress Bar Style", 'modeltheme-addons-for-wpbakery'),
          "param_name" => "bar_style",
          "value" => array(
            'Select Option'     => '',
            'Simple'     => 'simple',
            'Striped'    => 'progress-bar-striped'
          )
        ),
        array(
          "type" => "vc_number",
          "holder" => "div",
          "class" => "",
          "heading" => esc_attr__("Progress Bar Value (1-100)", 'modeltheme-addons-for-wpbakery'),
          "param_name" => "bar_value",
          "value" => ""
        ),
        array(
          "type" => "vc_number",
          "holder" => "div",
          "class" => "",
          "heading" => esc_attr__("Progress Bar Value width", 'modeltheme-addons-for-wpbakery'),
          "param_name" => "width_progress",
          "value" => ""
        ),
        array(
          "type" => "textarea",
          "holder" => "div",
          "class" => "",
          "heading" => esc_attr__("Progress Bar Label", 'modeltheme-addons-for-wpbakery'),
          "param_name" => "bar_label",
          "value" => " "
        ),
        array(
          "group" => "Styling",
          "type" => "colorpicker",
          "holder" => "div",
          "class" => "",
          "heading" => esc_attr__("Text Color", 'modeltheme-addons-for-wpbakery'),
          'description' => __( 'Select text Color.', 'modeltheme-addons-for-wpbakery' ),
          "param_name" => "color"
        ),
        array(
          "group" => "Styling",
          "type" => "colorpicker",
          "holder" => "div",
          "class" => "",
          "heading" => esc_attr__("Bg Color", 'modeltheme-addons-for-wpbakery'),
          'description' => __( 'Select bg Color.', 'modeltheme-addons-for-wpbakery' ),
          "param_name" => "background_progress"
        ),
      )
  ));
}