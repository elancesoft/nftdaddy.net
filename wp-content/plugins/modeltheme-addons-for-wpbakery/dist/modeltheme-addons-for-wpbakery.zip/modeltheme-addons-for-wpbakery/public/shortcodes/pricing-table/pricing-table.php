<?php
if ( ! defined( 'ABSPATH' ) ) {
  die( '-1' );
}

function modeltheme_addons_for_wpbakery_pricing_table($params, $content) {
  extract( shortcode_atts( 
    array(
      'package_currency'             => '',
      'package_price'                => '',
      'price_size'                   => '',
      'package_name'                 => '',
      'title_size'                   => '',
      'package_description'          => '',
      'description_size'             => '',
      'editor_content'               => '',
      'button_url'                   => '',
      'package_name_color'           => '',
      'price_color'                  => '',
      'package_description_color'    => '',
      'btn_size'                     => '',
      'btn_style'                    => '',
      'font_size'                    => '',
      'button_bg_color'              => '',
      'button_color'                 => '',
      'package_background_color'     => '',
      'border_color'                 => '',

    ), $params ) );
   
    $params['editor_content'] = $content;

    wp_enqueue_style( 'mt-pricing-table', plugins_url( '../../css/pricing-table.css' , __FILE__ ));

    ob_start(); 
    $url_link = vc_build_link($button_url); ?>

    <div class="mt-addons-pricing-table-section" style="background:<?php echo esc_attr($package_background_color); ?>; ">
        <h2 class="mt-addons-pricing-table-title" style="color:<?php echo esc_attr($package_name_color); ?>; font-size:<?php echo esc_attr($title_size); ?>px;"><?php echo esc_html($package_name); ?></h2>
          <p class="mt-addons-pricing-table-price" style="color:<?php echo esc_attr($price_color); ?>; font-size:<?php echo esc_attr($price_size); ?>px;">
            <span><?php echo esc_attr($package_currency); ?></span><?php echo esc_attr($package_price); ?>
          </p>
          <p class="mt-addons-pricing-table-sub text-center" style="color:<?php echo esc_attr($package_description_color); ?>;font-size:<?php echo esc_attr($description_size); ?>px;"><?php echo esc_html($package_description); ?>
          </p>
          <div class="mt-addons-pricing-table-feature">
            <?php echo html_entity_decode($content); ?>
          </div>
        <div class="mt-addons-pricing-table-button-holder text-center">
          <a class="mt-addons-pricing-table-button <?php echo esc_attr($btn_size.' '.$btn_style); ?>"
            style="font-size: <?php echo esc_attr($font_size.'px'); ?>;        
            background-color: <?php echo esc_attr($button_bg_color); ?>;
            color: <?php echo esc_attr($button_color); ?>;"
            target="<?php echo esc_attr($url_link['target']); ?>" 
            rel="<?php echo esc_attr($url_link['rel']); ?>" 
            href="<?php echo esc_url($url_link['url']); ?>">
            <?php echo esc_html($url_link['title']); ?>
          </a>
        </div>
      </div>
      <style type="text/css" media="screen">
        .mt-addons-pricing-table-section:hover {
          border-top:3px solid <?php echo $border_color; ?>;
          transition: border-color 0.5s;
        }
      </style>
    <?php
    return ob_get_clean();
}
add_shortcode('mt-addons-pricing-table', 'modeltheme_addons_for_wpbakery_pricing_table');

//VC Map
if (function_exists('vc_map')) {
  vc_map(
    array(
      "name" => esc_attr__("MT: Pricing Table", "modeltheme-addons-for-wpbakery"),
      "base" => "mt-addons-pricing-table",
      "category" => esc_attr__('MT Addons', "modeltheme-addons-for-wpbakery"),
      "icon" => plugins_url( 'images/pricing-table.svg', __FILE__ ),
      "params" => array(
        array(
          "type" => "textfield",
          "holder" => "div",
          "class" => "",
          "heading" => esc_attr__("Package name", "modeltheme-addons-for-wpbakery"),
          "param_name" => "package_name",
          "value" => ""
        ),
        array(
          "type" => "vc_number",
          "suffix" => "px",
          "class" => "",
          "heading" => esc_attr__( "Font size", "modeltheme-addons-for-wpbakery" ),
          "param_name" => "title_size"
        ),
        array(
          "type" => "vc_number",
          "holder" => "div",
          "class" => "",
          "heading" => esc_attr__("Package price", "modeltheme-addons-for-wpbakery"),
          "param_name" => "package_price",
          "value" => ""
        ),
        array(
          "type" => "vc_number",
          "suffix" => "px",
          "class" => "",
          "heading" => esc_attr__( "Price size", "modeltheme-addons-for-wpbakery" ),
          "param_name" => "price_size"
        ),
        array(
          "type" => "textfield",
          "holder" => "div",
          "class" => "",
          "heading" => esc_attr__("Package currency", "modeltheme-addons-for-wpbakery"),
          "param_name" => "package_currency",
          "value" => ""
        ),
        array(
          "type" => "textfield",
          "holder" => "div",
          "class" => "",
          "heading" => esc_attr__("Package Description", "modeltheme-addons-for-wpbakery"),
          "param_name" => "package_description",
          "value" => ""
        ),
        array(
          "type" => "vc_number",
          "suffix" => "px",
          "class" => "",
          "heading" => esc_attr__( "Description size", "modeltheme-addons-for-wpbakery" ),
          "param_name" => "description_size"
        ),
        array(
          'type' => 'textarea_html',
          "holder" => "div",
          "class" => "",
          "heading" => esc_attr__("Package's feature", "modeltheme-addons-for-wpbakery"),
          "param_name" => "content",
          "value" => ""
        ),
        array(
          "group" => "Pricing Button",
          "type" => "vc_link",
          "holder" => "div",
          "class" => "",
          "heading" => esc_attr__("Package Button Text and URL", "modeltheme-addons-for-wpbakery"),
          "param_name" => "button_url",
          "value" => esc_attr__("#", "modeltheme-addons-for-wpbakery")
        ),
        array(
          "group" => "Pricing Button",
          "type" => "dropdown",
          "heading" => esc_attr__("Size", "modeltheme-addons-for-wpbakery"),
          "param_name" => "btn_size",
          "value" => array(
            'Select Option'     => '',
            esc_attr__('Small', "modeltheme-addons-for-wpbakery")   => 'btn btn-sm',
            esc_attr__('Medium', "modeltheme-addons-for-wpbakery")   => 'btn btn-medium',
            esc_attr__('Large', "modeltheme-addons-for-wpbakery")   => 'btn btn-lg',
            esc_attr__('Extra-Large', "modeltheme-addons-for-wpbakery")   => 'extra-large'
          ),
          "std" => 'normal',
          "holder" => "div",
          "class" => "",
        ),
        array(
          "group"     =>  'Pricing Button',
          "type"      =>  "vc_number",
          "heading"     =>  esc_html__( 'Font Size', 'accordion' ),
          "param_name"  =>  "font_size",
          "description"   =>  esc_html__( 'in pixels', 'accordion' ),
          "value"     =>  ""
        ),
        array(
          "group" => "Pricing Button",
          "type" => "dropdown",
          "heading" => esc_attr__("Shape", "modeltheme-addons-for-wpbakery"),
          "param_name" => "btn_style",
          "value" => array(
            'Select Option'     => '',
            esc_attr__('Square (Default)', "modeltheme-addons-for-wpbakery")   => 'btn-square',
            esc_attr__('Rounded (5px Radius)', "modeltheme-addons-for-wpbakery")   => 'btn-rounded',
            esc_attr__('Round (30px Radius)', "modeltheme-addons-for-wpbakery")   => 'btn-round',
          )
        ),
        array(
          "group" => "Pricing Button",
          "type" => "colorpicker",
          "holder" => "div",
          "class" => "",
          "heading" => esc_attr__("Button Color", "modeltheme-addons-for-wpbakery"),
          'description' => __( 'Select Button Color.', "modeltheme-addons-for-wpbakery" ),
          "param_name" => "button_color"
        ),
        array(
          "group" => "Pricing Button",
          "type" => "colorpicker",
          "holder" => "div",
          "class" => "",
          "heading" => esc_attr__("Background Color", "modeltheme-addons-for-wpbakery"),
          'description' => __( 'Select Background Color.', "modeltheme-addons-for-wpbakery" ),
          "param_name" => "button_bg_color"
        ),
        array(
          "group" => "Styling",
          "type" => "colorpicker",
          "holder" => "div",
          "class" => "",
          "heading" => esc_attr__("Package Background Color", "modeltheme-addons-for-wpbakery"),
          'description' => __( 'Package Background Color.', "modeltheme-addons-for-wpbakery" ),
          "param_name" => "package_background_color"
        ),
        array(
          "group" => "Styling",
          "type" => "colorpicker",
          "holder" => "div",
          "class" => "",
          "heading" => esc_attr__("Title Color", "modeltheme-addons-for-wpbakery"),
          'description' => __( 'Select Title Color.', "modeltheme-addons-for-wpbakery" ),
          "param_name" => "package_name_color"
        ),
        array(
          "group" => "Styling",
          "type" => "colorpicker",
          "holder" => "div",
          "class" => "",
          "heading" => esc_attr__("Price Color", "modeltheme-addons-for-wpbakery"),
          'description' => __( 'Select Price Color.', "modeltheme-addons-for-wpbakery" ),
          "param_name" => "price_color"
        ),
        array(
          "group" => "Styling",
          "type" => "colorpicker",
          "holder" => "div",
          "class" => "",
          "heading" => esc_attr__("Description Color", "modeltheme-addons-for-wpbakery"),
          'description' => __( 'Select Description Color.', "modeltheme-addons-for-wpbakery" ),
          "param_name" => "package_description_color"
        ),
        array(
          "group" => "Styling",
          "type" => "colorpicker",
          "holder" => "div",
          "class" => "",
          "heading" => esc_attr__("Border Color", "modeltheme-addons-for-wpbakery"),
          'description' => __( 'Select Border Color.', "modeltheme-addons-for-wpbakery" ),
          "param_name" => "border_color"
        ),
      )
  ));
}