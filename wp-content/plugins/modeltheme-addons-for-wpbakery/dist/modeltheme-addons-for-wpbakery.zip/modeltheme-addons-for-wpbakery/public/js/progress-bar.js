
const progress = document.querySelector('.mt-addons-progress-bar-done');

setTimeout(() => {
  progress.style.opacity = 1;
  progress.style.width = progress.getAttribute('data-progress') + '%';
}, 500)
