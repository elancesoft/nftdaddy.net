<?php
if ( ! defined( 'ABSPATH' ) ) {
  die( '-1' );
}

if (!function_exists('modeltheme_addons_swiper_vc_fields')) {
  function modeltheme_addons_swiper_vc_fields(){
    $swiper_vc_fields = array(
      array(
        "type" => "dropdown",
        "holder" => "div",
        "class" => "",
        "heading" => esc_attr__('Layout', 'modeltheme-addons-for-wpbakery'),
        "param_name" => "layout",
        "value" => array(
         'Select Layout'   => '',
          'Carousel'       => 'carousel',
          'Grid'           => 'grid'
         ),
      ),
      array(
        "type" => "vc_number",
        "holder" => "div",
        "class" => "",
        "heading" => esc_attr__('Visible Items (Desktop)', 'modeltheme-addons-for-wpbakery'),
        "param_name" => "items_desktop",
        "dependency" => array(
          'element' => 'layout',
          'value' => 'carousel',
        ),
      ),
      array(
        "type" => "checkbox",
        "holder" => "div",
        "class" => "",
        "heading" => esc_attr__('AutoPlay', 'modeltheme-addons-for-wpbakery'),
        "param_name" => "autoplay",
        "dependency" => array(
          'element' => 'layout',
          'value' => 'carousel',
        ),
      ),
      array(
        "type" => "vc_number",
        "holder" => "div",
        "min" => '500',
        "max" => '10000',
        "step" => '100',
        "value" => "600",
        "heading" => esc_attr__('Slide Speed (in ms)', 'modeltheme-addons-for-wpbakery'),
        "param_name" => "delay",
        "dependency" => array(
          'element' => 'layout',
          'value' => 'carousel',
        ),
      ),
      array(
        "type" => "checkbox",
        "holder" => "div",
        "class" => "",
        "heading" => esc_attr__('Navigation (Left/Right Arrows)', 'modeltheme-addons-for-wpbakery'),
        "param_name" => "navigation",
        "dependency" => array(
          'element' => 'layout',
          'value' => 'carousel',
        ),
      ),
      array(
        "type" => "checkbox",
        "holder" => "div",
        "class" => "",
        "heading" => esc_attr__('Navigation Transition', 'modeltheme-addons-for-wpbakery'),
        "param_name" => "transition",
        "dependency" => array(
          'element' => 'layout',
          'value' => 'carousel',
        ),
      ),
      array(
        "type" => "checkbox",
        "holder" => "div",
        "class" => "",
        "heading" => esc_attr__('Pagination (dots)', 'modeltheme-addons-for-wpbakery'),
        "param_name" => "pagination",
        "dependency" => array(
          'element' => 'layout',
          'value' => 'carousel',
        ),
      ),
      array(
        "group" => "Responsive",
        "type" => "vc_number",
        "holder" => "div",
        "class" => "",
        "heading" => esc_attr__('Visible Items (Mobiles)', 'modeltheme-addons-for-wpbakery'),
        "param_name" => "items_mobile",
        "dependency" => array(
          'element' => 'layout',
          'value' => 'carousel',
        ),
      ),
      array(
        "group" => "Responsive",
        "type" => "vc_number",
        "holder" => "div",
        "class" => "",
        "heading" => esc_attr__('Visible Items (Tablets)', 'modeltheme-addons-for-wpbakery'),
        "param_name" => "items_tablet",
        "dependency" => array(
          'element' => 'layout',
          'value' => 'carousel',
        ),
      ),
      array(
        "type" => "vc_number",
        "holder" => "div",
        "class" => "",
        "heading" => esc_attr__('Space Between Items', 'modeltheme-addons-for-wpbakery'),
        "param_name" => "space_items",
        "dependency" => array(
          'element' => 'layout',
          'value' => 'carousel',
        ),
      ),
      array(
        "type" => "checkbox",
        "holder" => "div",
        "class" => "",
        "heading" => esc_attr__('Allow Touch Move', 'modeltheme-addons-for-wpbakery'),
        "param_name" => "touch_move",
        "dependency" => array(
          'element' => 'layout',
          'value' => 'carousel',
        ),
      ),
      array(
        "type" => "dropdown",
        "holder" => "div",
        "class" => "",
        "heading" => esc_attr__('Carousel Effect', 'modeltheme-addons-for-wpbakery'),
        "param_name" => "effect",
        "value" => array(
         'Select Effect'   => '',
          'Creative'   => 'creative',
          'Cards'      => 'cards',
          'Coverflow'  => 'coverflow',
          'Cube'       => 'cube',
          'Fade'       => 'fade',
          'Flip'       => 'flip',
         ),
        "dependency" => array(
          'element' => 'layout',
          'value' => 'carousel',
        ),
      ),
      array(
        "type" => "checkbox",
        "holder" => "div",
        "class" => "",
        "heading" => esc_attr__('Grab Cursor', 'modeltheme-addons-for-wpbakery'),
        "param_name" => "grab_cursor",
        "dependency" => array(
          'element' => 'layout',
          'value' => 'carousel',
        ),
      ),
      array(
        "type" => "checkbox",
        "holder" => "div",
        "class" => "",
        "heading" => esc_attr__('Infinite Loop', 'modeltheme-addons-for-wpbakery'),
        "param_name" => "infinite_loop",
        "dependency" => array(
          'element' => 'layout',
          'value' => 'carousel',
        ),
      ),
      array(
        "type" => "checkbox",
        "holder" => "div",
        "class" => "",
        "heading" => esc_attr__('Centered Slides', 'modeltheme-addons-for-wpbakery'),
        "param_name" => "centered_slides",
        "dependency" => array(
          'element' => 'layout',
          'value' => 'carousel',
        ),
      ),
      array(
        "type" => "dropdown",
        "holder" => "div",
        "class" => "",
        "heading" => esc_attr__('Columns', 'modeltheme-addons-for-wpbakery'),
        "param_name" => "columns",
        "value" => array(
          'Select Option'     => '',
          '2 Columns'     => 'col-md-6',
          '3 Columns'     => 'col-md-4',
          '4 Columns'     => 'col-md-3',
          '6 Columns'     => 'col-md-2'
        ),
        "dependency" => array(
          'element' => 'layout',
          'value' => 'grid',
        ),
      ),
    );

    return $swiper_vc_fields;
  }
}

if (!function_exists('modeltheme_addons_swiper_attributes')) {
  function modeltheme_addons_swiper_attributes($id = '', $autoplay = '', $delay = '', $items_desktop = '', $navigation = '', $pagination = '', $items_mobile = '', $items_tablet = '', $space_items = '', $touch_move = '', $effect = '', $grab_cursor = '', $infinite_loop = '', $centered_slides = ''){
    ?>
        data-swiper-id="<?php echo esc_attr($id); ?>" 
        data-swiper-autoplay="<?php echo esc_attr($autoplay); ?>"
        data-swiper-delay="<?php echo esc_attr($delay); ?>" 
        data-swiper-desktop-items="<?php echo esc_attr($items_desktop); ?>" 
        data-swiper-navigation="<?php echo esc_attr($navigation); ?>" 
        data-swiper-pagination="<?php echo esc_attr($pagination); ?>"
        data-swiper-mobile-items="<?php echo esc_attr($items_mobile); ?>" 
        data-swiper-tablet-items="<?php echo esc_attr($items_tablet); ?>" 
        data-swiper-space-between-items="<?php echo esc_attr($space_items); ?>" 
        data-swiper-allow-touch-move="<?php echo esc_attr($touch_move); ?>" 
        data-swiper-effect="<?php echo esc_attr($effect); ?>"
        data-swiper-grab-cursor ="<?php echo esc_attr($grab_cursor); ?>"
        data-swiper-infinite-loop ="<?php echo esc_attr($infinite_loop); ?>"
        data-swiper-centered-slides ="<?php echo esc_attr($centered_slides); ?>"

    <?php 
  }
}