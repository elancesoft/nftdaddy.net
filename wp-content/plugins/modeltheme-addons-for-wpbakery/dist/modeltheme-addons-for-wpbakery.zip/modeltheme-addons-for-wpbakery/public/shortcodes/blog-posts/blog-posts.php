<?php
if ( ! defined( 'ABSPATH' ) ) {
  die( '-1' );
}

function modeltheme_addons_for_wpbakery_blog_posts_carousel($params, $content) {
  extract( shortcode_atts( 
    array(
      'number'                   => '',
      'comments_blog'            => '',
      'category'                 => '',
      'text_color'               => '',
      'read_more_btn'            => '',
      'button_background'        => '',
      'button_color'             => '',
      'date_color'               => '',
      'background_color_ov'      => '',
      'autoplay'                 => '',
      'delay'                    => '', 
      'items_desktop'            => '3',
      'navigation'               => '',
      'pagination'               => '',
      'items_mobile'             => '',
      'items_tablet'             => '',
      'space_items'              => '',
      'touch_move'            => '',
      'effect'                => '',
      'grab_cursor'           => '',
      'infinite_loop'         => '',
      'centered_slides'      => '',
      'transition'        =>'',
      'carousel'                 => '',
      'columns'                  => 'col-md-4',
      'layout'                   => 'grid',
      'excerpt_blog'             => 'true'

    ), $params ) );


    $args_posts = array(
      'posts_per_page'        => $number,
      'post_type'             => 'post',
      'tax_query' => array(
        array(
          'taxonomy' => 'category',
          'field'    => 'slug',
          'terms'    => $category 
        )
      ),
      'post_status'           => 'publish' 
    );

    
    $posts = new WP_Query( $args_posts );

    $overlay_bg_style = '';
    if ($background_color_ov) {
      $overlay_bg_style = 'background:'.$background_color_ov.';';
    }
    if ($read_more_btn) {
        $button_text_value = $read_more_btn;
    }else{
        $button_text_value = __('Read More', 'modeltheme-addons-for-wpbakery');
    }
    // custom
    wp_enqueue_style( 'blog-posts-carousel', plugins_url( '../../css/blog-posts.css' , __FILE__ ));

    $id = 'mt-addons-swipper-'.uniqid();

    $carousel_item_class = $columns;
    $carousel_holder_class = '';
    $swiper_wrapped_start = '';
    $swiper_wrapped_end = '';
    $swiper_container_start = '';
    $swiper_container_end = '';
    $html_post_swiper_wrapper = '';

    if ($layout == "carousel" or $layout == "") {
      $carousel_holder_class = 'mt-addons-swipper swiper';
      $carousel_item_class = 'swiper-slide';

      $swiper_wrapped_start = '<div class="swiper-wrapper">';
      $swiper_wrapped_end = '</div>';

      $swiper_container_start = '<div class="mt-addons-swiper-container">';
      $swiper_container_end = '</div>';

      if ($transition == "true") {
        $swiper_container_start = '<div class="mt-addons-swiper-container">';
        $swiper_container_end = '</div>';
      }

      if ($navigation == "true") {
        // next/prev
        $html_post_swiper_wrapper .= '<i class="far fa-arrow-left swiper-button-prev"></i><i class="far fa-arrow-right swiper-button-next"></i>';
      }
      if ($pagination == "true") {
        // next/prev
        $html_post_swiper_wrapper .= '<div class="swiper-pagination"></div>';
      }

      // SWIPER SLIDER
      wp_enqueue_style( 'swiper-bundle', plugins_url( '../../css/plugins/swiperjs/swiper-bundle.min.css' , __FILE__ ));
      wp_enqueue_script( 'swipper-bundle', plugins_url( '../../js/plugins/swiperjs/swiper-bundle.min.js' , __FILE__));
      wp_enqueue_script( 'swipper', plugins_url( '../../js/swiper.js' , __FILE__));

    }

    ob_start(); ?>

      <!-- dir="rtl" -->
      <?php //swiper container start ?>
      <?php echo wp_kses_post($swiper_container_start); ?>
        <div id="<?php echo esc_attr($id); ?>" 
          <?php modeltheme_addons_swiper_attributes($id, $autoplay, $delay, $items_desktop, $navigation, $pagination, $items_mobile, $items_tablet, $space_items, $touch_move, $effect, $grab_cursor, $infinite_loop, $centered_slides); ?>
          class="mt-addons-blog-posts-carousel row <?php echo esc_attr($carousel_holder_class); ?>">

          <?php //swiper wrapped start ?>
          <?php echo wp_kses_post($swiper_wrapped_start); ?>
                   
            <?php if ( $posts->have_posts() ) : ?>
                <?php /* Start the Loop */ ?>
                <?php
                while ( $posts->have_posts() ) : $posts->the_post(); 
                  $thumbnail_src = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ),'full' );
                  $comments_count = wp_count_comments(get_the_ID());
                  $comments = '<a href="'.get_comments_link(get_the_ID()).'">'.sprintf( _n( '%s Comment', '%s Comments', $comments_count->approved, 'modeltheme-addons-for-wpbakery' ), number_format_i18n( $comments_count->approved ) ) .'</a>';
                  $post_content = get_post_field('post_content', get_the_ID());
                  ?>
                  <div class="mt-addons-blog-posts-carousel-single-post <?php echo esc_attr($carousel_item_class); ?>">
                    <div class="mt-addons-blog-posts-carousel-single-post-wrapper" style="<?php echo $overlay_bg_style; ?>">
                      <div class="mt-addons-blog-posts-carousel-custom"> 

                        <div class="mt-addons-blog-posts-carousel-thumbnail">
                            <?php if($thumbnail_src) { ?>
                              <div class="mt-addons-blog-featured-image">
                                <img src="<?php echo esc_attr($thumbnail_src[0]);?>" alt="<?php echo esc_attr(get_the_title());?>" />
                                <div class="mt-addons-blog-posts-carousel-button">
                                  <div class="mt-addons-blog-posts-carousel-content-inside"style="background-color:<?php echo $button_background; ?>">
                                    <a href="<?php echo get_permalink(get_the_ID())?>" class="relative" style="color:<?php echo $button_color; ?>">
                                      <?php echo esc_html($button_text_value); ?>
                                    </a>
                                  </div>
                                </div>
                              </div>
                            <?php } ?>
                        </div>
                      </div>
                      <div class="mt-addons-blog-posts-carousel-head-content">
                        <div class="mt-addons-blog-posts-carousel-date" style="color:<?php echo $date_color; ?>">
                          <span><?php echo get_the_time('j ',get_the_ID());?></span><?php echo get_the_time('M, Y',get_the_ID());?>
                            <?php if ($comments_blog == "true") { ?>
                           | <a style="color:<?php echo $date_color; ?>" href="<?php echo get_permalink(get_the_ID());?>" ><?php echo $comments; ?></a>
                            <?php } ?>
                        </div>
                        <h3 class="mt-addons-blog-posts-carousel-post-name"><a href="<?php echo get_permalink(get_the_ID());?>" style="color:<?php echo esc_attr($text_color);?>"><?php echo esc_attr(get_the_title());?></a></h3>
                        <?php if ($excerpt_blog == "true") { ?>
                          <div class="mt-addons-blog-posts-excerpt"><p><?php echo strip_tags(modeltheme_addons_excerpt_limit($post_content, 15));?>...</p></div>
                        <?php } ?>
                      </div>
                    </div>
                  </div>

                <?php endwhile; ?>
                <?php wp_reset_postdata(); ?>
            <?php else : ?>
                <?php //no posts found ?>
            <?php endif; ?>

          <?php //swiper wrapped end ?>
          <?php echo wp_kses_post($swiper_wrapped_end); ?>
        </div>
        <?php //pagination/navigation ?>
        <?php echo wp_kses_post($html_post_swiper_wrapper); ?>
      <?php //swiper container end ?>
      <?php echo wp_kses_post($swiper_container_end); ?>


    <?php
    return ob_get_clean();
}
add_shortcode('mt-addons-blog-posts-carousel', 'modeltheme_addons_for_wpbakery_blog_posts_carousel');

add_action('init', 'mt_addons_blog_posts_vc_map');
function mt_addons_blog_posts_vc_map(){
  //VC Map
  if (function_exists('vc_map')) {
    $post_category_tax = get_terms('category');
    $post_category = array();
    if ($post_category_tax) {
      foreach ( $post_category_tax as $term ) {
        $post_category[$term->name] = $term->slug;
      }
    }

    $params = array(
      array(
        "type" => "vc_number",
        "holder" => "div",
        "class" => "",
        "heading" => esc_attr__( "Number", 'modeltheme-addons-for-wpbakery' ),
        "param_name" => "number"
      ),
      array(
        "type" => "dropdown",
        "holder" => "div",
        "class" => "",
        "heading" => esc_attr__("Category", 'modeltheme-addons-for-wpbakery'),
        "param_name" => "category",
        "std" => 'Default value',
        "value" => $post_category
      ),
      array(
        "type" => "textfield",
        "holder" => "div",
        "class" => "",
        "heading" => esc_attr__( "Read More Text", 'modeltheme-addons-for-wpbakery' ),
        "param_name" => "read_more_btn"
      ),
      array(
        "type" => "checkbox",
        "class" => "",
        "heading" => esc_attr__("Comments", 'modeltheme-addons-for-wpbakery'),
        "param_name" => "comments_blog",
        "value"       => array(
          "Enabled" => "true",
        ),
      ),
      array(
        "type" => "checkbox",
        "class" => "",
        "heading" => esc_attr__("Excerpt", 'modeltheme-addons-for-wpbakery'),
        "param_name" => "excerpt_blog",
        "value"       => array(
          "Enabled" => "true",
        ),
      ),
      array(
        "group" => "Styling",
        "type" => "colorpicker",
        "holder" => "div",
        "class" => "",
        "heading" => esc_attr__("Title color", 'modeltheme-addons-for-wpbakery'),
        "param_name" => "text_color"
      ),
      array(
        "group" => "Styling",
        "type" => "colorpicker",
        "holder" => "div",
        "class" => "",
        "heading" => esc_attr__("Box Background color", 'modeltheme-addons-for-wpbakery'),
        "param_name" => "background_color_ov"
      ),
      array(
        "group" => "Styling",
        "type" => "colorpicker",
        "holder" => "div",
        "class" => "",
        "heading" => esc_attr__("Button Background", 'modeltheme-addons-for-wpbakery'),
        "param_name" => "button_background"
      ),
      array(
        "group" => "Styling",
        "type" => "colorpicker",
        "holder" => "div",
        "class" => "",
        "heading" => esc_attr__("Button text Color", 'modeltheme-addons-for-wpbakery'),
        "param_name" => "button_color"
      ),
      array(
        "group" => "Styling",
        "type" => "colorpicker",
        "holder" => "div",
        "class" => "",
        "heading" => esc_attr__("Date text Color", 'modeltheme-addons-for-wpbakery'),
        "param_name" => "date_color"
      ),
    );
    
    $swiper_fields_array = modeltheme_addons_swiper_vc_fields();
    if ($swiper_fields_array) {
      foreach ($swiper_fields_array as $swiper_fields) {
        $params[] = $swiper_fields;
      }
    }

    $extras_vc_fields = modeltheme_addons_extras_vc_fields();
    if ($extras_vc_fields) {
      foreach ($extras_vc_fields as $extra_param) {
        $params[] = $extra_param;
      }
    }

    vc_map(
      array(
        "name" => esc_attr__("MT: Blog Posts (Grid / Carousel)", 'modeltheme-addons-for-wpbakery'),
        "base" => "mt-addons-blog-posts-carousel",
        "category" => esc_attr__('MT Addons', 'modeltheme-addons-for-wpbakery'),
        "icon" => plugins_url( 'images/blog.svg', __FILE__ ),
        "params" => $params,
    ));
  }
}
